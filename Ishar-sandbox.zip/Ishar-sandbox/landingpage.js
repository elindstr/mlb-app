$(document).ready(function(){
    alert("testing")

    $("#teamModal").modal('show');
    $('#teanModal').modal({backdrop: static, keyboard: false})

    $("#teamID").bind('change', function()
{
    alert("testing")
});




});


