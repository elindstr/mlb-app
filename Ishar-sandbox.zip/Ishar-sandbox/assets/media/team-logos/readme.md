# MLB Team Logos

* saved by team_id (a key in the lookup-service-prod.mlb.com API)

* downloaded from [The SportsLogos.Net](https://www.sportslogos.net/teams/list_by_year/42023/2023_MLB_Logos/) on 2024-01-19. SportsLogos.Net requests only a link-back acknowledgement.


